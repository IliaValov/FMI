#pragma once
enum StockType
{
	None = 0,
	Perishable = 1,
	Packed = 2,
	WithstandingHeat = 3,
	Stagnant = 4,	
};

