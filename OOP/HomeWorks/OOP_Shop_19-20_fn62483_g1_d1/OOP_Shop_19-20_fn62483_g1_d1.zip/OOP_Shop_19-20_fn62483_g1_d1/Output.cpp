#include "Output.h"

const bool Output::WriteOnConsole()
{
	return false;
}

const bool Output::WriteLineOnConsole()
{
	return false;
}

const bool Output::WriteOnFile(const String& path, const String& fileName)
{
	return false;
}

const bool Output::WriteLineOnFile(const String& path, const String& fileName)
{
	return false;
}
