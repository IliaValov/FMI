#include "Output.h"

bool Output::WriteOnConsole()
{
	return false;
}

bool Output::WriteLineOnConsole()
{
	return false;
}

bool Output::WriteOnFile(String path, String fileName)
{
	return false;
}

bool Output::WriteLineOnFile(String path, String fileName)
{
	return false;
}
