#include "Output.h"

const bool Output::WriteOnConsole()
{
	return false;
}

const bool Output::WriteLineOnConsole()
{
	return false;
}

const bool Output::WriteOnFile(const  std::string& path, const  std::string& fileName)
{
	return false;
}

const bool Output::WriteLineOnFile(const  std::string& path, const  std::string& fileName)
{
	return false;
}
