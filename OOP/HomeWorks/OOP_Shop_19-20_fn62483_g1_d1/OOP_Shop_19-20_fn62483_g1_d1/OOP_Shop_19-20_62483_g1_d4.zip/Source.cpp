//#include <iostream>
//
//class Asteroid
//{
//private:
//    static int numOfAsteroids;
//public:
//    Asteroid()
//    {
//        numOfAsteroids++;
//        std::cout << "numOfAsteroids = " << numOfAsteroids << std::endl;
//    }
//    ~Asteroid()
//    {
//        numOfAsteroids--;
//        std::cout << "numOfAsteroids = " << numOfAsteroids << std::endl;
//    }
//};
//int Asteroid::numOfAsteroids = 0; // definition outside class declaration
//
//int main()
//{
//    Asteroid A;
//    Asteroid B;
//    return 0;
//}