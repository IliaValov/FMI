#pragma once
#include<iostream>
#include<string>

const std::string ADMIN_ROLE = "Admin";