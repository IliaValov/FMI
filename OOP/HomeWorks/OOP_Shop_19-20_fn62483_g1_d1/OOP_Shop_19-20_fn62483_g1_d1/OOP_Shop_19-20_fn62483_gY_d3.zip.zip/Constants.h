#pragma once
#include "String.h"

const String ADMIN_ROLE = "Admin";